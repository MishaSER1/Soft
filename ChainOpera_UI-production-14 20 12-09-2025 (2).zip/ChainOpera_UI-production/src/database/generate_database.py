import random
from getpass import getpass

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import delete

from loguru import logger
from eth_account import Account

from src.database.base_models.pydantic_manager import DataBaseManagerConfig
from src.database.models import WorkingWallets, WalletsTasks
from src.database.utils.db_manager import DataBaseUtils
from config import *
from src.utils.encryption import encrypt_data


async def clear_database(engine) -> None:
    async with AsyncSession(engine) as session:
        async with session.begin():
            for model in [WorkingWallets, WalletsTasks]:
                await session.execute(delete(model))
            await session.commit()
    logger.info("The database has been cleared")


async def generate_database(
        engine,
        private_keys: list[str],
        proxies: list[str],
        # twitter_tokens: list[str],
        # discord_tokens: list[str],
        # emails: list[str]
) -> None:
    await clear_database(engine)

    tasks = []
    # if RELAY_BRIDGE: tasks.append('RELAY_BRIDGE')
    if CHAT: tasks.append('CHAT')
    if CHECK_IN: tasks.append('CHECK_IN')
    # if COMPLETE_QUESTS: tasks.append('COMPLETE_QUESTS')
    # if GAS_ZIP: tasks.append('GAS_ZIP')

    has_relay_bridge = 'RELAY_BRIDGE' in tasks
    has_gas_zip = 'GAS_ZIP' in tasks
    has_check_in = 'CHECK_IN' in tasks

    proxy_index = 0

    logger.info("🔐 Введите пароль для шифрования приватных ключей:")
    encryption_password = getpass(">>> ")

    for private_key in private_keys:
        address = Account.from_key(private_key).address

        salt, encrypted_key = encrypt_data(private_key, encryption_password)

        with open('data/wallets.txt') as file:
            file_private_keys = [line.strip() for line in file]

        other_tasks = [
            task for task in tasks if
            task not in ['RELAY_BRIDGE', 'CHECK_IN', 'GAS_ZIP']
        ]
        random.shuffle(other_tasks)

        tasks = (
                (['GAS_ZIP'] if has_gas_zip else []) +
                (['RELAY_BRIDGE'] if has_relay_bridge else []) +
                (['CHECK_IN'] if has_check_in else []) +
                other_tasks
        )

        twitter_token = None
        discord_token = None
        email = None
        private_key_index = file_private_keys.index(private_key)
        # if "COMPLETE_QUESTS" in tasks:
        #     if len(twitter_tokens) != len(private_keys):
        #         logger.error('Number of twitter tokens does not match number of private keys.')
        #         return
        #     if len(discord_tokens) != len(private_keys):
        #         logger.error('Number of discord tokens does not match number of private keys.')
        #         return
        #     if len(emails) != len(private_keys):
        #         emails += [None]*(len(private_keys) - len(emails))
        #         # logger.error('Number of emails does not match number of private keys.')
        #         # return
        #
        #     twitter_token = twitter_tokens[private_key_index]
        #     discord_token = discord_tokens[private_key_index]
        #     email = emails[private_key_index]

        if len(proxies) >= len(private_keys):
            proxy = proxies[private_key_index]
        else:
            proxy = proxies[proxy_index]
            proxy_index = (proxy_index + 1) % len(proxies)

        proxy_url = None
        change_link = ''

        if proxy:
            if MOBILE_PROXY:
                proxy_url, change_link = proxy.split('|')
            else:
                proxy_url = proxy

        db_utils = DataBaseUtils(
            manager_config=DataBaseManagerConfig(
                action='working_wallets'
            )
        )

        await db_utils.add_to_db(
            private_key=encrypted_key,
            address=address,
            salt=salt,
            proxy=f'{proxy_url}|{change_link}' if MOBILE_PROXY else proxy_url,
            # twitter_token=twitter_token,
            # discord_token=discord_token,
            # email=email,
            status='pending',
        )

        for task in tasks:
            db_utils = DataBaseUtils(
                manager_config=DataBaseManagerConfig(
                    action='wallets_tasks'
                )
            )
            await db_utils.add_to_db(
                private_key=encrypted_key,
                address=address,
                status='pending',
                task_name=task
            )
