import asyncio
import re
from pathlib import Path
from typing import Optional, Tuple, List

from loguru import logger
from patchright.async_api import async_playwright, TimeoutError as PWTimeout, Page

from config import PAUSE_BETWEEN_ACTIONS, RETRIES, PAUSE_BETWEEN_RETRIES, PROFILES, RESET_RABBY, ERASE_TRACE
from src.utils.common.wrappers.decorators import retry, relogin
from src.utils.fingerprint.mouse_utils import prime_mouse, human_click
from src.utils.fingerprint.profile_pruner import rabby_wipe_async, wipe_traces_async
from src.utils.proxy_manager import Proxy
from src.utils.rabby_handler.rabby import Rabby
from src.utils.sleeps import nap
from src.utils.web3_utils import evm_address_from_privkey

# use your new browser helpers
from src.utils.fingerprint.cherry_browser import launch_profile, get_proxy_get  # uses PROFILES/EXT_DIR internally

# =========================
# Proxy + context utilities
# =========================


async def _page_fetch_json(page, url: str, timeout_ms: int = 20000) -> Optional[dict]:
    """Fetch JSON from inside the browser context (so it really tests the proxy)."""
    try:
        return await page.evaluate(
            """
            async ({ url, to }) => {
              const ctl = new AbortController();
              const id = setTimeout(() => ctl.abort(), to);
              try {
                const r = await fetch(url, { cache: "no-store", signal: ctl.signal });
                return await r.json();
              } finally {
                clearTimeout(id);
              }
            }
            """,
            {"url": url, "to": timeout_ms}
        )
    except Exception:
        return None


async def _open_context_with_retry(
        pw_browser_type,
        *,
        account: str,
        proxy_url: str,
        extensions: Optional[List[str]] = None,
        headless: bool = False,
        channel: str = "chrome",
        precheck_timeout: float = 15.0,
        recreate_tries: int = 2,
):
    try:
        meta = await get_proxy_get(proxy=proxy_url, timeout=precheck_timeout)
        logger.success(
            f"[{account}] proxy precheck ok: ip={meta.get('query')} cc={meta.get('countryCode')} tz={meta.get('timezone')}")
    except Exception as e:
        logger.error(f"[{account}] proxy precheck failed: {e}")
        raise Exception("proxy")

    last_reason = ""
    for attempt in range(1, recreate_tries + 2):
        ctx = None
        try:
            ctx = await launch_profile(
                pw_browser_type,
                account=account,
                extensions=extensions,
                proxy_url=proxy_url,
                headless=headless,
                channel=channel,
            )
            logger.info(f"[{account}] context launched (attempt {attempt})")
            return ctx
        except Exception as e:
            last_reason = f"launch error: {e}"
            logger.warning(f"[{account}] Context launch error on attempt {attempt}: {e}")

        if ctx:
            try:
                await ctx.close()
            except Exception:
                pass
        await asyncio.sleep(min(2 * attempt, 6))

    logger.error(f"[{account}] Giving up after retries; last reason: {last_reason}")
    raise Exception(last_reason)


# =========================
# ChainOpera UI (Rabby mixin)
# =========================

class ChainOperaUI(Rabby):
    """
    Compose persistent Chromium context (from askaer_browser) + Rabby helpers.
    IMPORTANT: Construct via `await ChainOperaUI.create_for_privkey(...)` (async factory).
    """

    def __init__(self):
        self.context = None
        self._pw = None  # async_playwright handle
        self._rabby_password: Optional[str] = None
        self.meta = {}

    @classmethod
    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def create_for_privkey(
            cls,
            *,
            private_key: str,
            proxy: Proxy | None,
            extension_dir: Path | None,
            rabby_password: str | None = None,
    ) -> "ChainOperaUI":
        self = cls()
        address = evm_address_from_privkey(private_key)
        self.meta = {"address": address}
        self._rabby_password = rabby_password

        proxy_url = None
        if isinstance(proxy, Proxy) and getattr(proxy, "proxy_url", None):
            proxy_url = proxy.proxy_url
        elif isinstance(proxy, str):
            proxy_url = proxy

        if ERASE_TRACE:
            res = await wipe_traces_async(
                profiles_root=PROFILES/address,
            )
            logger.debug(f"[{address}] | Trace deletion status: {res.get('ok', False)}")

        if RESET_RABBY:
            try:
                res = await rabby_wipe_async(
                    user_data_dir=PROFILES/address/"user_data_dir",
                    profile_name="Default",
                    ext_id_hint=None,
                )
                logger.success(f"[{address}] | Rabby reset status: {res.get('ok', False)}")
            except Exception as e:
                logger.debug(f"[{address}] | Rabby wipe crashed: {e}")
                pass

        # start playwright and keep the handle (so runner can call tracing, close, etc.)
        self._pw = await async_playwright().start()
        try:
            browser_type = getattr(self._pw, "chromium")
            account_alias = address

            ctx = await _open_context_with_retry(
                browser_type,
                account=account_alias,
                proxy_url=proxy_url,
                extensions=[str(extension_dir)] if extension_dir else None,
                headless=False,
                channel="chrome",
                recreate_tries=2,
            )
            # if we got here, we have a context
            self.context = ctx
            await self.rabby_attach(password=rabby_password, private_key=private_key)
            return self

        except Exception as e:
            await self.close()
            raise Exception(e)

    async def close(self):
        """Close context and stop Playwright."""
        try:
            if self.context:
                await self.context.close()
        except Exception:
            pass
        finally:
            self.context = None
            try:
                if self._pw:
                    await self._pw.stop()
            except Exception:
                pass
            self._pw = None

    async def healthcheck(self, timeout_ms: int = 25000) -> dict:
        """
        Check external network identity from inside the current browser context.
        Returns a normalized dict and logs a concise line.
        """
        if not self.context:
            raise RuntimeError("Context is not initialized")

        page = await self.context.new_page()
        try:
            ipapi = await _page_fetch_json(page, "http://ip-api.com/json", timeout_ms)
            public_ip = (ipapi or {}).get("query")
            try:
                browser_tz = await page.evaluate("() => Intl.DateTimeFormat().resolvedOptions().timeZone")
            except Exception:
                browser_tz = None

            tz = None
            if ipapi and ipapi.get("query"):
                tz = ipapi.get("timezone")
            else:
                ipwho = await _page_fetch_json(page, "https://ipwho.is/", timeout_ms)
                if ipwho and ipwho.get("success"):
                    public_ip = public_ip or ipwho.get("ip")
                    tzinfo = (ipwho or {}).get("timezone") or {}
                    tz = tzinfo.get("id")

            result = {
                "ip": public_ip,
                "timezone": tz or browser_tz,  # provider tz → fallback to browser tz
                "browser_tz": browser_tz,
            }

            addr = self.meta.get("address", "")
            logger.info(
                f"[{addr}] healthcheck: ip={result['ip']} "
                f"tz={result['timezone']} (browser={result['browser_tz']})"
            )
            return result
        except Exception as e:
            logger.error(f"[{self.meta.get("address")}] | Healthcheck failed: {e}")
        finally:
            try:
                await page.close()
            except Exception:
                pass

    # ---- site flows ----

    async def _relogin_in_place(self, page) -> bool:
        """
        Perform ChainOpera re-login *in the same tab* using Rabby.
        No URL branching – we just drive the login flow.
        """
        short = getattr(self, "meta", {}).get("address", "")
        try:
            logger.info(f"[{short}] | Re-login started.")
            # pick Rabby and go through wallet handler
            rabby_btn = page.get_by_role("button", name=re.compile(r"Rabby Wallet", re.I))
            await rabby_btn.wait_for(state="visible", timeout=10000)
            await self.rabby_click_then_handle(
                human_click(rabby_btn, padding=2),
                allowed_actions={"connect", "switch", "sign", "confirm"},
                total_budget_ms=40_000,
            )

            # settle & verify token
            await nap(PAUSE_BETWEEN_ACTIONS[0], PAUSE_BETWEEN_ACTIONS[1])
            try:
                token = await page.evaluate("localStorage.getItem('auth_token')")
            except Exception:
                token = None

            if token:
                logger.success(f"[{short}] | Re-login successful.")
                return True

            # last-chance: wait a bit for token to appear
            try:
                await page.wait_for_function(
                    "() => !!localStorage.getItem('auth_token')",
                    timeout=20_000
                )
                logger.success(f"[{short}] | Re-login successful (delayed token).")
                return True
            except PWTimeout:
                logger.warning(f"[{short}] | Re-login finished but token not found.")
                return False

        except PWTimeout as e:
            logger.error(f"[{short}] | Re-login timed out: {e}")
            return False
        except Exception as e:
            logger.error(f"[{short}] | Re-login failed: {e}")
            return False

    @relogin(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def open_chain_opera(self):
        """
        Opens https://chat.chainopera.ai and handles Rabby connect if needed.
        Returns a Page (you own it) or None on failure.
        """
        page = await self.context.new_page()
        await nap(3, 10)
        await prime_mouse(page)

        await page.goto("https://chat.chainopera.ai/", wait_until="domcontentloaded", timeout=30000)
        await nap(PAUSE_BETWEEN_ACTIONS[0], PAUSE_BETWEEN_ACTIONS[1])

        if page.url == "https://chat.chainopera.ai/":
            login_button = page.get_by_role("button", name=re.compile("Login", re.I))
            if await login_button.is_visible():
                await human_click(login_button, padding=1)
                await nap(PAUSE_BETWEEN_ACTIONS[0], PAUSE_BETWEEN_ACTIONS[1])

        if page.url.startswith("https://chat.chainopera.ai/login"):
            rabby_button = page.get_by_role("button", name=re.compile("Rabby Wallet", re.I))
            await self.rabby_click_then_handle(
                human_click(rabby_button, padding=3),
                allowed_actions={"connect", "switch", "sign", "confirm"},
                total_budget_ms=40000,
            )
            await nap(PAUSE_BETWEEN_ACTIONS[0], PAUSE_BETWEEN_ACTIONS[1])

        local_storage_data = await page.evaluate("localStorage.getItem('auth_token')")
        if local_storage_data:
            return page

        logger.error(f"[{self.meta.get('address')}] | Got an error logging in to ChainOpera.")
        try:
            await page.close()
        except Exception:
            pass
        return None

    @staticmethod
    async def get_earned_points(page, timeout=15000) -> int | None:
        container = page.get_by_text(re.compile(r"^You've earned", re.I))
        await container.wait_for(state="visible", timeout=timeout)
        span = container.locator("span.font-semibold").first
        txt = (await span.inner_text()).strip()
        m = re.search(r"([\d,]+)", txt)
        return int(m.group(1).replace(",", "")) if m else None

    @relogin(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def make_check_in(self, page):
        """
        Clicks the daily check-in card and handles Rabby if needed.
        Returns True if check-in completed, False if already checked in, None on error.
        """
        if page.url != "https://chat.chainopera.ai/":
            await page.goto("https://chat.chainopera.ai/", wait_until="domcontentloaded", timeout=30000)

        profile_button = page.get_by_role("button", name=re.compile(r"0x\S{4}\.{3}\S{6}"))
        await human_click(profile_button, padding=2, lpad=90)
        await nap(PAUSE_BETWEEN_ACTIONS[0], PAUSE_BETWEEN_ACTIONS[1])
        async with page.expect_response(
                lambda r: "userCenter/api/v1/ai/terminal/getRateLimit" in r.url,
                timeout=60_000
        ) as resp_info:
            checkin_tile = page.locator(
                "div.group-hover\\:animate-bounce"
            )
            await checkin_tile.wait_for(state="visible", timeout=10000)
            await human_click(checkin_tile, padding=1)
        resp = await resp_info.value
        if resp.status == 200:
            data = await resp.json()
            if data.get("code") == "SUCCESS" and data.get("data"):
                logger.success(f"[{self.meta.get('address')}] | Already checked in today, skipping.")
                return True

        try:
            recharge = page.get_by_role("button", name=re.compile(r"recharge", re.I))
            await recharge.wait_for(state="visible", timeout=5000)
            if await recharge.count():
                logger.warning(f"[{self.meta.get('address')}] | Not enough balance for check-in...")
                close_sign = page.locator("button", has=page.locator("svg.lucide-x"))
                await human_click(close_sign)
                return None
        except PWTimeout:
            pass

        checkin_button = page.get_by_role("button", name=re.compile(r"Check-In", re.I))
        await self.rabby_click_then_handle(
            human_click(checkin_button, padding=2),
            allowed_actions={"connect", "switch", "sign", "confirm"},
            total_budget_ms=50000,
        )

        await nap(PAUSE_BETWEEN_ACTIONS[0], PAUSE_BETWEEN_ACTIONS[1])
        got_it = page.get_by_role("button", name=re.compile(r"Got it!", re.I))
        points = await self.get_earned_points(page) or 0
        if await got_it.count():
            await human_click(got_it, padding=2)
            logger.success(f"[{self.meta.get('address')}] | Successfully checked-in and got {points}")
            return True

        logger.warning(f"[{self.meta.get('address')}] | Could not complete check-in...")
        return None

    @staticmethod
    def assemble_streamed_text(raw: str) -> str:
        parts = []
        for line in raw.splitlines():
            m = re.match(r'^0:"(.*)"$', line.strip())
            if m:
                token = m.group(1)
                token = token.encode('utf-8').decode('unicode_escape')
                parts.append(token)
        return "".join(parts).strip()

    @relogin(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def send_message(self, page: Page, message: str, firstskip: bool = False):
        """
        Sends message to chat.
        Returns True if message is sent, False if not, None on error.
        """
        if not page.url.startswith("https://chat.chainopera.ai/chat/") or firstskip:
            await page.goto("https://chat.chainopera.ai/", wait_until="domcontentloaded", timeout=30000)

        chat_area = page.get_by_placeholder("Ask AI anything...")
        await human_click(chat_area, padding=15, bottompad=30)
        await chat_area.fill(message)

        async with page.expect_response(
                url_or_predicate="https://chat.chainopera.ai/api/agentopera",
                timeout=120_000
        ) as resp_info:
            await chat_area.press("Enter")
            try:
                recharge = page.get_by_text(text=re.compile(r"Check-In on Chain", re.I))
                await recharge.wait_for(state="visible", timeout=5000)
                if await recharge.count():
                    logger.warning(f"[{self.meta.get('address')}] | You need to check-in in order to chat...")
                    close_sign = page.locator("button", has=page.locator("svg.lucide-x"))
                    await human_click(close_sign)
                    return "NOCHECKIN"
            except PWTimeout:
                pass

        resp = await resp_info.value

        try:
            await resp.finished()
        except Exception:
            pass

        raw = await resp.text()
        full_text = self.assemble_streamed_text(raw)
        return full_text
