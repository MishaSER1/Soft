# mappings.py
from src.utils.fingerprint.ctx_manager import co_manager
from src.utils.runner import process_check_in, process_chat
from src.models.route import Route

async def check_in_with_ctx(route: Route):
    co = await co_manager.get(route)
    return await process_check_in(route, co=co)

async def chat_with_ctx(route: Route):
    co = await co_manager.get(route)
    return await process_chat(route, co=co)

module_handlers = {
    'CHECK_IN': check_in_with_ctx,
    'CHAT': chat_with_ctx,
}
