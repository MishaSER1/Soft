import datetime
from typing import Any, Optional
import csv
from colorama import Fore

with open('config.py', 'r', encoding='utf-8-sig') as file:
    module_config = file.read()

exec(module_config)

with open('data/wallets.txt', 'r', encoding='utf-8-sig') as file:
    private_keys = [line.strip() for line in file]

with open('data/proxies.txt', 'r', encoding='utf-8-sig') as file:
    proxies = [line.strip() for line in file]
    if not proxies:
        proxies = [None for _ in range(len(private_keys))]

print(Fore.BLUE + f'Loaded {len(private_keys)} wallets:')
print('\033[39m')


def dump_to_csv(
        headers: tuple[str] | list[str],
        data: tuple | list,
        total: Optional[tuple | list | None] = None
) -> str:
    file_name = f"checker_results/stats_{datetime.datetime.now().strftime('%H_%M_%d_%m')}.csv"
    with open(file_name, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for result in data:
            if isinstance(result, tuple) and len(result) == 3:
                writer.writerow(result)
            else:
                writer.writerow(("N/A", "N/A"))
        if total:
            writer.writerow(total)
    return file_name
