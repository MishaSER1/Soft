# minimal_cleanup.py
import os, stat, shutil, asyncio, subprocess
from pathlib import Path

SAFE_DIRS = [
    "Cache", "Code Cache", "GPUCache", "Media Cache",
    "DawnCache", "ShaderCache", "GrShaderCache",
    "VideoDecodeStats", "OptimizationGuidePredictionModels",
    "Safe Browsing",
]


def _remove_readonly(func, path, exc_info):
    try:
        os.chmod(path, stat.S_IWRITE)
    except:
        pass
    func(path)


def _rmtree_sync(p: Path) -> bool:
    try:
        shutil.rmtree(p, onerror=_remove_readonly)
        return True
    except:
        return False


def _win_rd_sync(p: Path) -> bool:
    try:
        r = subprocess.run(
            ["cmd", "/c", "rd", "/s", "/q", str(p)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
        return r.returncode == 0 or not p.exists()
    except:
        return False


async def prune_profile_dirs_async(user_data_dir: str, profile_name: str = "Default",
                                   max_concurrency: int = 3, per_dir_timeout: float = 60.0) -> dict:
    prof = Path(user_data_dir) / profile_name
    if not prof.exists():
        return {"ok": False, "reason": "profile_not_found"}

    paths = [prof / d for d in SAFE_DIRS if (prof / d).exists()]
    sem = asyncio.Semaphore(max_concurrency)
    is_win = os.name == "nt"
    results = {}

    async def delete_one(p: Path):
        async with sem:
            ok = False
            if is_win:
                ok = await asyncio.to_thread(_win_rd_sync, p)
            if not ok:
                ok = await asyncio.to_thread(_rmtree_sync, p)
            if not ok and p.exists():
                ok = await asyncio.to_thread(_rmtree_sync, p)  # добивка
            results[str(p)] = "OK" if ok or (not p.exists()) else "FAILED"

    await asyncio.gather(*(
        asyncio.wait_for(delete_one(p), timeout=per_dir_timeout) for p in paths
    ))

    return {"ok": True, "deleted": results}


def _guess_rabby_eids_sync(default_dir: Path, ext_id_hint: str | None) -> list[str]:
    if ext_id_hint:
        return [ext_id_hint]
    les_root = default_dir / "Local Extension Settings"
    if not les_root.exists():
        return []
    return [p.name for p in les_root.iterdir() if p.is_dir() and len(p.name) == 32]


async def rabby_wipe_async(
        user_data_dir: str,
        profile_name: str = "Default",
        ext_id_hint: str | None = None,
) -> dict:
    default_dir = Path(user_data_dir) / profile_name
    if not default_dir.exists():
        return {"ok": False, "status": "error", "reason": "profile_not_found", "path": str(default_dir)}

    eids = await asyncio.to_thread(_guess_rabby_eids_sync, default_dir, ext_id_hint)
    if not eids:
        return {"ok": True, "status": "skipped", "reason": "eid_not_found"}

    is_win = os.name == "nt"
    results, any_deleted = {}, False

    async def _delete_dir(p: Path) -> bool:
        ok = False
        if is_win:
            ok = await asyncio.to_thread(_win_rd_sync, p)
        if not ok:
            ok = await asyncio.to_thread(_rmtree_sync, p)
        return ok or (not p.exists())

    for eid in eids:
        targets: list[Path] = []

        les = default_dir / "Local Extension Settings" / eid
        if les.exists():
            targets.append(les)

        if not targets:
            results[eid] = {"status": "skipped", "reason": "nothing_to_delete"}
            continue

        statuses = []
        for p in targets:
            try:
                ok = await _delete_dir(p)
            except Exception as e:
                ok = False
                statuses.append({"path": str(p), "status": "failed", "error": f"{type(e).__name__}: {e}"})
            else:
                statuses.append({"path": str(p), "status": "deleted" if ok else "failed"})
                any_deleted = any_deleted or ok

        results[eid] = {"items": statuses}

    return {"ok": any_deleted, "status": "done" if any_deleted else "skipped", "results": results}


def _unlink_sync(p: Path) -> dict:
    if not p.exists():
        return {"path": str(p), "status": "skipped"}
    try:
        p.unlink()
        return {"path": str(p), "status": "deleted"}
    except Exception as e:
        return {"path": str(p), "status": "failed", "error": f"{type(e).__name__}: {e}"}


async def wipe_traces_async(
    profiles_root: str | Path,
) -> dict:

    root = Path(profiles_root)
    paths = [root / "f_manager_trace.zip", root / "full_trace.zip", root / "trace.zip",
             root/"rabby_import_trace_1.zip", root/"rabby_import_trace_2.zip", root/"rabby_import_trace_3.zip",]

    results = await asyncio.gather(*(asyncio.to_thread(_unlink_sync, p) for p in paths))
    any_deleted = any(r.get("status") == "deleted" for r in results)
    return {"ok": any_deleted, "results": results}