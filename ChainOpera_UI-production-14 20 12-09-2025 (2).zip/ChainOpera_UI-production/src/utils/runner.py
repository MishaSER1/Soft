# runner.py
import codecs
import random
import re
from typing import Optional

from loguru import logger

from config import PROFILES, EXT_DIR, SAVE_TRACE, ChatSettings, PAUSE_BETWEEN_ACTIONS, OPENAI_API_KEY
from src.models.route import Route
from src.modules.chain_opera.chainopera_ctx import ChainOperaUI
from src.utils.gpt.gpt_client import GPTClient
from src.utils.sleeps import nap


async def process_check_in(route: Route, co: ChainOperaUI | None = None) -> Optional[bool]:
    created_here = co is None
    if created_here:
        logger.debug(f"[{route.wallet.address}] | Initializing ChainOpera client")
        co = await ChainOperaUI.create_for_privkey(
            private_key=route.wallet.private_key,
            proxy=route.wallet.proxy,
            extension_dir=EXT_DIR,
            rabby_password=route.wallet.rabby_password,
        )
        if not co:
            logger.warning(f"[{route.wallet.address}] | Failed to initialize ChainOpera client")
            return None
        await nap(1.5, 3.5)
        if SAVE_TRACE:
            await co.context.tracing.start(screenshots=True, snapshots=True, sources=True)
            await co.context.tracing.start_chunk()
        imported = await co.ensure_rabby_imported()
        if SAVE_TRACE:
            await co.context.tracing.stop_chunk(path=f"./profiles/{route.wallet.address}/rabby_import_trace_2.zip")
            await co.context.tracing.start_chunk()
        if not imported:
            await co.close()
            return False
        logger.success(f"[{route.wallet.address}] | Successfully imported wallet to Rabby")
        await nap(2.0, 4.0)

    try:
        page = await co.open_chain_opera()
        checked_in = False
        if page:
            checked_in = await co.make_check_in(page)
            await nap(2.0, 5.0)
            await page.close()
        return True if isinstance(checked_in, bool) and checked_in else None
    except Exception as e:
        logger.error(f"[{route.wallet.address}] | Failed to chek-in: {e}")
    finally:
        if created_here:
            if SAVE_TRACE:
                await co.context.tracing.stop_chunk(path=f"./profiles/{route.wallet.address}/f_manager_trace.zip")
                await co.context.tracing.stop()
            await nap(1.0, 5.0)
            await co.close()


def clean_message(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r'(?<!\n)\n(?!\n)', ' ', text)
    text = text.replace('\\\\', '\\')
    try:
        text = codecs.decode(text, 'unicode_escape')
    except UnicodeDecodeError:
        pass
    text = re.sub(r'[^a-zA-Zа-яА-Я0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


async def process_chat(route: Route, co: ChainOperaUI | None = None) -> Optional[bool]:
    created_here = co is None
    if created_here:
        logger.debug(f"[{route.wallet.address}] | Initializing ChainOpera client")
        co = await ChainOperaUI.create_for_privkey(
            private_key=route.wallet.private_key,
            proxy=route.wallet.proxy,
            extension_dir=EXT_DIR,
            rabby_password=route.wallet.rabby_password,
        )
        if not co:
            logger.warning(f"[{route.wallet.address}] | Failed to initialize ChainOpera client")
            return None
        await nap(1.5, 3.5)
        if SAVE_TRACE:
            await co.context.tracing.start(screenshots=True, snapshots=True, sources=True)
            await co.context.tracing.start_chunk()
        imported = await co.ensure_rabby_imported()
        if SAVE_TRACE:
            await co.context.tracing.stop_chunk(path=f"./profiles/{route.wallet.address}/rabby_import_trace_3.zip")
            await co.context.tracing.start_chunk()
        if not imported:
            await co.close()
            return False
        logger.success(f"[{route.wallet.address}] | Successfully imported wallet to Rabby")
        await nap(2.0, 4.0)

    try:
        page = await co.open_chain_opera()
        await nap(2.0, 5.0)

        gpt_client = GPTClient(proxy=route.wallet.proxy, openai_api_key=OPENAI_API_KEY)
        total_sent = 0
        if page:
            initial_message = random.choice(ChatSettings.greet_messages)
            max_total_messages = random.randint(ChatSettings.num_messages[0], ChatSettings.num_messages[1])
            current_message = initial_message
            while total_sent < max_total_messages:
                response = await co.send_message(page, clean_message(current_message), not bool(total_sent))
                if response == "NOCHECKIN":
                    break
                logger.debug(f'[{route.wallet.address}] | ChainOpera Response: {response}')
                total_sent += 1

                gpt_response = await gpt_client.send_message(clean_message(response))
                if not gpt_response:
                    logger.warning(f'[{route.wallet.address}] | Пустой ответ от GPT, прерываю диалог.')
                    break

                logger.debug(f'[{route.wallet.address}] | GPT Response: {gpt_response}')
                current_message = gpt_response

                if total_sent < max_total_messages:
                    await nap(PAUSE_BETWEEN_ACTIONS[0], PAUSE_BETWEEN_ACTIONS[1])
                    continue

            await nap(2.0, 5.0)
            await page.close()

        return True if total_sent > 0 else None
    except Exception as e:
        logger.error(f"[{route.wallet.address}] | Failed to process chat: {e}")
    finally:
        if created_here:
            if SAVE_TRACE:
                await co.context.tracing.stop_chunk(path=f"./profiles/{route.wallet.address}/f_manager_trace.zip")
                await co.context.tracing.stop()
            await nap(1.0, 5.0)
            await co.close()
