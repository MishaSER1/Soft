import asyncio, random
from aiohttp import ClientSession
from loguru import logger
from src.utils.data.helper import proxies  # pool of "host:port" or full urls

def _normalize(url: str) -> str:
    return url if "://" in url else f"http://{url}"

class Proxy:
    def __init__(self, proxy_url: str, change_link: str | None = None):
        self.change_link = change_link
        self.proxy_url = _normalize(proxy_url)
        self._client = None
        self._pool = [p if "://" in p else f"http://{p}" for p in (proxies or [])]

    def attach_client(self, client):
        self._client = client

    def _get_random_proxy(self) -> str:
        pool = list({ _normalize(p) for p in proxies })
        candidates = [p for p in pool if p != self.proxy_url]
        return random.choice(candidates or pool)

    async def change(self):
        choices = [p for p in self._pool if p != self.proxy_url] or self._pool or [self.proxy_url]
        self.proxy_url = random.choice(choices)
        logger.info(f"proxy rotated → {self.proxy_url}")

    async def _change_ip(self):
        if not self.change_link:
            return
        while True:
            try:
                async with ClientSession() as session:
                    r = await session.get(self.change_link)
                    if r.status == 200:
                        logger.debug("Successfully changed IP via change_link")
                        return
                    logger.error(f"Failed to change IP, status={r.status}")
            except Exception as ex:
                logger.error(f"Error during IP change: {ex}")
            await asyncio.sleep(3)
