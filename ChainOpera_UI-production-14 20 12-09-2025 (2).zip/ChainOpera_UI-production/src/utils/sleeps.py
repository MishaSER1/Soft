import asyncio
import random


def jitter(base: float = 1.0, spread: float = 0.5) -> float:
    """Return a randomized duration around `base` (uniform in [base-spread, base+spread])."""
    lo = max(0.0, base - spread)
    hi = base + spread
    return random.uniform(lo, hi)

async def nap(min_s: float = 3.0, max_s: float = 10.0) -> float:
    """Async sleep for a random duration in [min_s, max_s], returns the duration."""
    dur = random.uniform(min_s, max_s)
    await asyncio.sleep(dur)
    return dur