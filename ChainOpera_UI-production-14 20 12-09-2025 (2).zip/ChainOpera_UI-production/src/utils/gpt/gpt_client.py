from httpx import AsyncClient
from config import RETRIES, PAUSE_BETWEEN_RETRIES
from src.utils.common.wrappers.decorators import retry
from src.utils.proxy_manager import Proxy
import asyncio, random
from typing import Optional
from g4f.client import AsyncClient as G4FAsyncClient
from g4f import errors as g4f_errors
from openai import AsyncOpenAI
from openai import APIError, APIStatusError, APIConnectionError, APITimeoutError

FALLBACK_MODELS = ("gpt-4o-mini", "gpt-4o", "o3-mini", "deepseek-chat", "llama-3.1-70b")
PAID_MODELS = ("gpt-4o-mini", "gpt-4o", "o3-mini")


class GPTClient:
    def __init__(
            self,
            proxy: Optional[Proxy],
            openai_api_key: Optional[str] = None,
            use_paid_first: bool = False,
            default_timeout_s: float = 20.0,
    ) -> None:
        self._proxy = proxy
        self._use_paid_first = bool(openai_api_key) or use_paid_first
        self._default_timeout_s = float(default_timeout_s)
        self.g4f = G4FAsyncClient(proxies=proxy.proxy_url if proxy else None)
        self.openai: Optional[AsyncOpenAI] = None
        if openai_api_key:
            http_client = AsyncClient(proxy=proxy.proxy_url if proxy else None)
            self.openai = AsyncOpenAI(
                api_key=openai_api_key,
                http_client=http_client,
                max_retries=0,
                timeout=self._default_timeout_s,
            )

    async def _once_paid(self, model: str, message: str, timeout_s: float) -> Optional[str]:
        if not self.openai:
            return None
        try:
            resp = await self.openai.chat.completions.create(
                model=model,
                messages=[{
                    "role": "user",
                    "content": (
                            "Assume you are a curious human. "
                            "Do not ever mention that you are an AI. Answer me only with a plain question, no other text included. "
                            f"At the end of your question include a favor to answer you in less than {random.randint(600, 1000)} symbols long."
                            "Make up a sophisticated question up to 600 symbols long out of this message: "
                            + message
                    )
                }],
                timeout=timeout_s,
            )
        except (APITimeoutError,):
            return None
        except (APIConnectionError, APIStatusError):
            return None
        except APIError:
            return None
        except Exception:
            return None

        choices = getattr(resp, "choices", None) or []
        if not choices:
            return None
        msg = getattr(choices[0], "message", None)
        text = getattr(msg, "content", None)
        return text.strip() if isinstance(text, str) and text.strip() else None

    async def _once_free(self, model: str, message: str, timeout_s: float) -> Optional[str]:
        try:
            response = await asyncio.wait_for(
                self.g4f.chat.completions.create(
                    model=model,
                    messages=[{
                        "role": "user",
                        "content": (
                                "Assume you are a curious human. "
                                "Do not ever mention that you are an AI. Answer me only with a plain question, no other text included. "
                                f"At the end of your question include a favor to answer you in less than {random.randint(600, 1000)} symbols long."
                                "Make up a sophisticated question up to 600 symbols long out of this message: "
                                + message
                        )
                    }],
                    web_search=False,
                ),
                timeout=timeout_s + 5,
            )
        except (asyncio.TimeoutError, g4f_errors.TimeoutError):
            return None
        except (g4f_errors.RateLimitError, g4f_errors.ResponseStatusError):
            return None
        except Exception:
            return None

        choices = getattr(response, "choices", None) or []
        if not choices:
            return None
        msg = getattr(choices[0], "message", None)
        text = getattr(msg, "content", None)
        return text.strip() if isinstance(text, str) and text.strip() else None

    async def _once(self, model: str, message: str, timeout_s: float = 60.0) -> Optional[str]:
        if self._use_paid_first and model in PAID_MODELS:
            text = await self._once_paid(model, message, timeout_s)
            if text:
                return text
        return await self._once_free(model, message, timeout_s)

    @retry(retries=RETRIES, delay=PAUSE_BETWEEN_RETRIES, backoff=1.5)
    async def send_message(self, message: str) -> str:
        attempt = 0
        models = list(FALLBACK_MODELS)
        random.shuffle(models)

        while attempt < 3:
            model = models[attempt % len(models)]
            text = await self._once(model, message, timeout_s=30.0)
            if text:
                return text
            await asyncio.sleep((attempt + 1) + random.uniform(0, 1.0))
            attempt += 1

        raise RuntimeError("All providers returned empty/invalid responses after multiple attempts")
