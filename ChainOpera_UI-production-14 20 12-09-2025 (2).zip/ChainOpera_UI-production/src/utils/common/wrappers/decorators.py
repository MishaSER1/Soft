from functools import wraps
from asyncio import sleep, iscoroutine
from loguru import logger
from patchright.async_api import TimeoutError as PWTimeout

from config import PAUSE_BETWEEN_ACTIONS
from src.utils.sleeps import nap


def retry(retries: int, delay: float, backoff: float = 1.5):
    """
    If the decorated callable is a @classmethod, we unwrap/rewrap it so order doesn't matter.
    On failure, if kwargs['proxy'] has an async .change() method, we await it before retrying.
    """

    def deco(obj):
        is_cm = isinstance(obj, classmethod)
        is_sm = isinstance(obj, staticmethod)
        func = obj.__func__ if (is_cm or is_sm) else obj

        @wraps(func)
        async def wrapped(*args, **kwargs):
            for attempt in range(retries + 1):
                try:
                    return await func(*args, **kwargs)
                except Exception as ex:
                    if attempt == retries:
                        logger.error(f"{func.__name__} failed after {retries} retries: {ex}")
                        return None

                    # Try to rotate proxy BETWEEN attempts if a Proxy object was passed
                    px = kwargs.get("proxy", None)
                    changer = getattr(px, "change", None)
                    if callable(changer):
                        logger.warning(f"[{func.__name__}] attempt {attempt + 1} failed → rotating proxy... {ex}")
                        res = changer()
                        if iscoroutine(res):
                            await res

                    await sleep(delay * (backoff ** attempt))

        if is_cm: return classmethod(wrapped)
        if is_sm: return staticmethod(wrapped)
        return wrapped

    return deco


def relogin(retries: int, delay: float, backoff: float = 1.5):
    """
    Re-login decorator in the style of your retry(...):
    - Works with regular functions, @classmethod, and @staticmethod (unwraps/rewraps).
    - On Playwright TimeoutError: do in-place re-login (self._relogin_in_place(page)), then retry.
    - Between attempts: exponential backoff (delay * backoff**attempt) + your nap cadence.
    - No proxy rotation, no URL checks.
    - Returns None on final failure (to match your style).
    Assumes the wrapped callable signature is (self, page, *args, **kwargs).
    """

    def deco(obj):
        is_cm = isinstance(obj, classmethod)
        is_sm = isinstance(obj, staticmethod)
        func = obj.__func__ if (is_cm or is_sm) else obj

        @wraps(func)
        async def wrapped(*args, **kwargs):
            self = args[0] if args else None
            page = args[1] if len(args) > 1 else kwargs.get("page")
            short = getattr(self, "meta", {}).get("address", "") if self else ""

            for attempt in range(retries + 1):
                try:
                    return await func(*args, **kwargs)

                except PWTimeout as ex:
                    if '120000ms' in str(ex).lower() or 'domcontentloaded' in str(ex).lower():
                        continue
                    logger.warning(f"[{short}] | {func.__name__} Timeout → re-login (attempt {attempt + 1}/{retries})")
                    ok = False
                    try:
                        if self and page and hasattr(self, "_relogin_in_place"):
                            ok = await self._relogin_in_place(page)
                        else:
                            logger.error(f"[{short}] | Cannot re-login: missing self/page/_relogin_in_place")
                    except Exception as relogin_ex:
                        logger.error(f"[{short}] | Re-login failed: {relogin_ex}")

                    if ok:
                        # settle like everywhere else in your code
                        await sleep(0.15)
                        await nap(PAUSE_BETWEEN_ACTIONS[0], PAUSE_BETWEEN_ACTIONS[1])
                        if attempt < retries:
                            continue
                        # exhausted retries but relogin succeeded → one last try
                        try:
                            return await func(*args, **kwargs)
                        except PWTimeout as ex2:
                            logger.error(f"{func.__name__} Failed after {retries} retries: {ex2}")
                            return None

                    # relogin didn't help
                    if attempt == retries:
                        logger.error(f"{func.__name__} Failed after {retries} retries: {ex}")
                        return None
                    await sleep(delay * (backoff ** attempt))
                    continue

                except Exception as ex:
                    # Non-timeout errors: backoff + retry (no relogin)
                    if attempt == retries:
                        logger.error(f"{func.__name__} Failed after {retries} retries: {ex}")
                        return None
                    await sleep(delay * (backoff ** attempt))
                    continue

        if is_cm:  return classmethod(wrapped)
        if is_sm:  return staticmethod(wrapped)
        return wrapped

    return deco
