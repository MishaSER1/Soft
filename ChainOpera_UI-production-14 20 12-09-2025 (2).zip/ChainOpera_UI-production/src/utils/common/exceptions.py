class TransactionFailedError(Exception):
    pass
