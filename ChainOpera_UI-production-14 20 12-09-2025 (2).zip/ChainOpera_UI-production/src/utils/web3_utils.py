from eth_account import Account

def evm_address_from_privkey(pk: str | bytes) -> str:
    if isinstance(pk, str):
        if pk.startswith("0x"):
            pk = pk[2:]
        pk_bytes = bytes.fromhex(pk)
    else:
        pk_bytes = pk
    if len(pk_bytes) != 32:
        raise ValueError("Private key must be 32 bytes.")
    return Account.from_key(pk_bytes).address