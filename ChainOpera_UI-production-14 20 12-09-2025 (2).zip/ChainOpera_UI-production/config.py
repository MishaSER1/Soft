from pathlib import Path

LICENSE_KEY = ''

MOBILE_PROXY = False  # True - мобильные proxy/False - обычные proxy
ROTATE_IP = False  # Настройка только для мобильных proxy

TG_BOT_TOKEN = ''  # str ('2282282282:MzAyMTkzNTM1ibKnAR3Hzq5z2HESgoOu_Q1x15NAVyqrnwBOCCCA7nI')
TG_USER_ID = None  # int (22822822) or None

SHUFFLE_WALLETS = False
PAUSE_BETWEEN_WALLETS = [30, 60]
PAUSE_BETWEEN_MODULES = [10, 20]
PAUSE_BETWEEN_ACTIONS = [4, 10] # Пауза между движениями, ставить от 4 секунд.
OPENAI_API_KEY = '' # Если есть апи ключ платный гпт, то вставляем сюда

MAX_PARALLEL_ACCOUNTS = 2 # Параллельное количество окон браузера
SAVE_TRACE = False # Сохранить запись прогона браузера для отладки
ERASE_TRACE = True # Удалить запись прогона перед запуском браузера, чтобы освободить место на диске
RESET_RABBY = False # Стереть данные Рабби, чтобы поменять пароль

RETRIES = 3  # Сколько раз повторять 'зафейленное' действие
PAUSE_BETWEEN_RETRIES = 15  # Пауза между повторами

CHAT = False
CHECK_IN = False

EXT_DIR = Path(__file__).parent.resolve() / "rabby" # Путь к папке с расширением рабби из папки с софтом
PROFILES = Path(__file__).parent.resolve() / "profiles" # Путь к папке с профилями

class ChatSettings:
    greet_messages = ['Hello', 'Hello, how are you?', 'Hi', 'Whats up']
    num_messages = [3, 5]  # Суммарное кол-во сообщений
