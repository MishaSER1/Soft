## Установка и запуск

1. Установите зависимости:
   ```bash
   pip install -r requirements.txt
2. Установите браузер хром
   ```bash
   playwright install
3. Скачайте расширение Rabby Wallet с https://github.com/RabbyHub/Rabby/releases/tag/v0.93.44 . Необходимо скачать архив Rabby_v0.93.44.zip
и распаковать его в папку rabby в папке с софтом. Если вы скачали и распаковали как надо, в папке rabby появился файл manifest.json

4. Запуск (первый модуль, потом второй):
   ```bash
   python main.py
Меню   
1) `Generate new database` - генерация БД
2) `Work with existing database` - отработка по БД
